create definer = info@`%` view VIEW_POSTOGRADUACAOQUADROS as
select `PGQ`.`CODPOSTOGRADUACAO_QUADROS` AS `CODPOSTOGRADUACAO_QUADROS`,
       `PG`.`CODPOSTOGRADUACAO`          AS `CODPOSTOGRADUACAO`,
       `PG`.`ORDEM`                      AS `ORDEM`,
       `Q`.`CODQUADROS`                  AS `CODQUADROS`,
       `PG`.`DESCRICAO`                  AS `POSTOGRAD`,
       `PG`.`ABREVIACAO`                 AS `PGABREV`,
       `Q`.`DESCRICAO`                   AS `QUADRO`,
       `Q`.`ABREVIACAO`                  AS `QABREV`,
       `QOD`.`CARGOS_TOTAL`              AS `CARGOS_TOTAL`,
       `Q`.`SERVICO_ATIVO`               AS `SERVICO_ATIVO`,
       `PG`.`EXCLUIDO`                   AS `EXCLUIDO`
from (((`intranet`.`RH_POSTOGRADUACAO_QUADROS` `PGQ` left join `intranet`.`RH_POSTOGRADUACAO` `PG`
        on ((`PG`.`CODPOSTOGRADUACAO` = `PGQ`.`CODPOSTOGRADUACAO`))) left join `intranet`.`RH_QUADROS` `Q`
       on ((`Q`.`CODQUADROS` = `PGQ`.`CODQUADROS`))) left join `intranet`.`RH_QOD` `QOD`
      on ((`QOD`.`CODPOSTOGRADUACAO_QUADROS` = `PGQ`.`CODPOSTOGRADUACAO_QUADROS`)));

