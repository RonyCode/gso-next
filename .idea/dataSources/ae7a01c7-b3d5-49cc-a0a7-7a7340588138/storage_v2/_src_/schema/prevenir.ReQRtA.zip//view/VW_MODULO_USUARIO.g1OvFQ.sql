create definer = info@`%` view VW_MODULO_USUARIO as
select distinct `PU`.`CODUSUARIO` AS `CODUSUARIO`,
                `M`.`CODMODULO`   AS `CODMODULO`,
                `M`.`MODULO`      AS `MODULO`,
                `M`.`DESCRICAO`   AS `DESCRICAO`,
                `M`.`IMAGEM`      AS `IMAGEM`,
                `M`.`PATH`        AS `PATH`,
                `M`.`ATIVO`       AS `ATIVO`
from (((`prevenir`.`PERFIL_SERVICO` `PS` join `prevenir`.`SERVICO` `S`
        on ((`S`.`CODSERVICO` = `PS`.`CODSERVICO`))) join `prevenir`.`MODULO` `M`
       on ((`S`.`CODMODULO` = `M`.`CODMODULO`))) join `prevenir`.`PERFIL_USUARIO` `PU`
      on ((`PU`.`CODPERFIL` = `PS`.`CODPERFIL`)));

