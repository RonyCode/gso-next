create definer = info@`%` view VIEW_CIDADES_TOCANTINS as
select `C`.`CODCIDADE` AS `CODCIDADE`,
       `C`.`CODESTADO` AS `CODESTADO`,
       `C`.`SIGLA`     AS `SIGLA`,
       `C`.`NOME`      AS `NOME`,
       `C`.`VERSAO`    AS `VERSAO`,
       `C`.`EXCLUIDO`  AS `EXCLUIDO`,
       `C`.`LATITUDE`  AS `LATITUDE`,
       `C`.`LONGITUDE` AS `LONGITUDE`
from `intranet`.`CIDADE` `C`
where ((`C`.`SIGLA` = 'TO') and (`C`.`CODESTADO` = 27));

