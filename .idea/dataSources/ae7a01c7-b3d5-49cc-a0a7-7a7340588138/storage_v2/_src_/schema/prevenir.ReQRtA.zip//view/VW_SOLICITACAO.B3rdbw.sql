create definer = info@`%` view VW_SOLICITACAO as
select `S`.`CODSOLICITACAO`          AS `CODSOLICITACAO`,
       `S`.`DATA`                    AS `DATA`,
       `S`.`NUMERO`                  AS `S_NUMERO`,
       `S`.`TIPO`                    AS `TIPO`,
       `S`.`TAXAEMITIDA`             AS `TAXAEMITIDA`,
       `S`.`REVENDAGLP`              AS `REVENDAGLP`,
       `S`.`CENTRALGLP`              AS `CENTRALGLP`,
       `S`.`REUNIAOPUBLICO`          AS `REUNIAOPUBLICO`,
       `S`.`TIPOEMPRESA`             AS `TIPOEMPRESA`,
       `S`.`SITUACAO`                AS `SITUACAO`,
       `S`.`EXCLUIDO`                AS `EXCLUIDO`,
       `S`.`CODIMOVEL`               AS `CODIMOVEL`,
       `I`.`UC`                      AS `UC`,
       `I`.`AREACONSTRUIDA`          AS `AREACONSTRUIDA`,
       `I`.`CODENDERECO`             AS `CODENDERECO`,
       `I`.`ALTURAEDIFICACAO`        AS `ALTURAEDIFICACAO`,
       `I`.`QTDPAVIMENTO`            AS `QTDPAVIMENTO`,
       `I`.`QTDPUBLICO`              AS `QTDPUBLICO`,
       `E`.`NUMERO`                  AS `E_NUMERO`,
       `E`.`CEP`                     AS `CEP`,
       `E`.`LOGRADOURO`              AS `LOGRADOURO`,
       `E`.`BAIRRO`                  AS `BAIRRO`,
       `E`.`LATITUDE`                AS `LATITUDE`,
       `E`.`LONGITUDE`               AS `LONGITUDE`,
       `E`.`COMPLEMENTO`             AS `COMPLEMENTO`,
       `E`.`CODCIDADE`               AS `CODCIDADE`,
       `C`.`NOME`                    AS `CIDADE`,
       `C`.`ESTADO`                  AS `ESTADO`,
       `S`.`CODPESSOA_SOLICITANTE`   AS `CODPESSOA_SOLICITANTE`,
       `IP`.`CODPESSOA_PROPRIETARIO` AS `CODPESSOA_PROPRIETARIO`,
       `IP`.`CODPESSOA_RESPONSAVEL`  AS `CODPESSOA_RESPONSAVEL`,
       `PF`.`CODPESSOA_FISICA`       AS `CODPESSOA_FISICA`,
       `PF`.`CPF`                    AS `CPF`,
       `PF`.`NOME`                   AS `SOLICITANTE`,
       `PF`.`DATANASCIMENTO`         AS `DATANASCIMENTO`,
       `P`.`EMAIL`                   AS `EMAIL`,
       `P`.`TELEFONE`                AS `TELEFONE`,
       `S`.`CODUNIDADEBM`            AS `CODUNIDADEBM`,
       `UN`.`NOME`                   AS `UNIDADEBM`,
       `IO`.`CODOCUPACAO`            AS `CODOCUPACAO`
from ((((((((`prevenir`.`SOLICITACAO` `S` join `prevenir`.`IMOVEL` `I`
             on ((`I`.`CODIMOVEL` = `S`.`CODIMOVEL`))) join `prevenir`.`ENDERECO` `E`
            on ((`E`.`CODENDERECO` = `I`.`CODENDERECO`))) join `prevenir`.`CIDADE` `C`
           on ((`C`.`CODCIDADE` = `E`.`CODCIDADE`))) join `prevenir`.`IMOVEL_PESSOA` `IP`
          on ((`S`.`CODIMOVEL` = `IP`.`CODIMOVEL`))) join `prevenir`.`PESSOA_FISICA` `PF`
         on ((`S`.`CODPESSOA_SOLICITANTE` = `PF`.`CODPESSOA`))) join `prevenir`.`PESSOA` `P`
        on ((`S`.`CODPESSOA_SOLICITANTE` = `P`.`CODPESSOA`))) join `prevenir`.`UNIDADEBM` `UN`
       on ((`S`.`CODUNIDADEBM` = `UN`.`CODUNIDADEBM`))) left join `prevenir`.`IMOVEL_OCUPACAO` `IO`
      on ((`S`.`CODIMOVEL` = `IO`.`CODIMOVEL`)));

-- comment on column VW_SOLICITACAO.TIPO not supported: 1 - NÃO ISENTO, 2 - ISENTO, 3 - NÃO ISENTO COM DEPOSITO DE GAS

-- comment on column VW_SOLICITACAO.SITUACAO not supported: 1 - EM ANDAMENTO\n2 - ARQUIVADO\n3 - CANCELADO\n4 - CASSADO

