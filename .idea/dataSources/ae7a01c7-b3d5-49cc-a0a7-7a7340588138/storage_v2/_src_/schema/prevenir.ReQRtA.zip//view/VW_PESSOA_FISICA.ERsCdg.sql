create definer = info@`%` view VW_PESSOA_FISICA as
select `P`.`CODPESSOA`         AS `CODPESSOA`,
       `P`.`DATACADASTRO`      AS `DATACADASTRO`,
       `P`.`EMAIL`             AS `EMAIL`,
       `P`.`TELEFONE`          AS `TELEFONE`,
       `PF`.`CODPESSOA_FISICA` AS `CODPESSOA_FISICA`,
       `PF`.`CPF`              AS `CPF`,
       `PF`.`NOME`             AS `NOME`,
       `PF`.`DATANASCIMENTO`   AS `DATANASCIMENTO`,
       `U`.`CODUSUARIO`        AS `CODUSUARIO`,
       `U`.`SENHA`             AS `SENHA`,
       `U`.`ULTIMOACESSO`      AS `ULTIMOACESSO`,
       `U`.`SITUACAO`          AS `SITUACAO`
from ((`prevenir`.`PESSOA` `P` join `prevenir`.`USUARIO` `U`
       on ((`P`.`CODPESSOA` = `U`.`CODPESSOA`))) join `prevenir`.`PESSOA_FISICA` `PF`
      on ((`P`.`CODPESSOA` = `PF`.`CODPESSOA`)));

