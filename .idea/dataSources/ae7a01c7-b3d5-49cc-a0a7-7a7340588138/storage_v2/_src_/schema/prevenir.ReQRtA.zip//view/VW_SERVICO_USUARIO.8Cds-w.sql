create definer = info@`%` view VW_SERVICO_USUARIO as
select `PU`.`CODUSUARIO` AS `CODUSUARIO`,
       `PU`.`GESTOR`     AS `GESTOR`,
       `PU`.`PERMISSAO`  AS `PERMISSAO`,
       `S`.`CODSERVICO`  AS `CODSERVICO`,
       `S`.`SERVICO`     AS `SERVICO`,
       `S`.`DESCRICAO`   AS `DESCRICAO`,
       `S`.`IMAGEM`      AS `IMAGEM`,
       `S`.`PATH`        AS `PATH`,
       `S`.`ATIVO`       AS `ATIVO`,
       `M`.`CODMODULO`   AS `CODMODULO`,
       `M`.`PATH`        AS `MODULO`,
       `M`.`MODULO`      AS `MODULONOME`
from (((`prevenir`.`PERFIL_SERVICO` `PS` join `prevenir`.`SERVICO` `S`
        on ((`S`.`CODSERVICO` = `PS`.`CODSERVICO`))) join `prevenir`.`MODULO` `M`
       on ((`S`.`CODMODULO` = `M`.`CODMODULO`))) join `prevenir`.`PERFIL_USUARIO` `PU`
      on ((`PU`.`CODPERFIL` = `PS`.`CODPERFIL`)));

-- comment on column VW_SERVICO_USUARIO.PERMISSAO not supported: PERMISSAO
INSERIR = 1;
EDITAR = 2;
EXCLUIR = 4;
TOTAL = 7 (FULL)

