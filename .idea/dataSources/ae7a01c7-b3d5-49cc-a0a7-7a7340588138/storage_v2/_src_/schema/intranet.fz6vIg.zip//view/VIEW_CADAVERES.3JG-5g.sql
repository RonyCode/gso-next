create definer = info@`%` view VIEW_CADAVERES as
select `C`.`LOCALIZADO`                               AS `LOCALIZADO`,
       `P`.`IDADEAPARENTE`                            AS `IDADEAPARENTE`,
       `P`.`CPF`                                      AS `CPF`,
       `P`.`SEXO`                                     AS `SEXO`,
       `C`.`CODOCORRENCIA`                            AS `CODOCORRENCIA`,
       `C`.`CODCADAVER`                               AS `CODCADAVER`,
       `C`.`CODPESSOA`                                AS `CODPESSOA`,
       `L`.`NOME`                                     AS `ORGAORECEBEDOR`,
       `L`.`SIGLA`                                    AS `SIGLAORGAORECEBEDOR`,
       `L`.`CODLOCAL`                                 AS `CODORGAORECEBEDOR`,
       date_format(`C`.`DATALOCALIZACAO`, '%d/%m/%Y') AS `DATALOCALIZACAO`,
       `P`.`NOME`                                     AS `NOME`
from ((`intranet`.`OP_PESSOA` `P` join `intranet`.`OP_CADAVER` `C`
       on (((`P`.`CODPESSOA` = `C`.`CODPESSOA`) and (`C`.`EXCLUIDO` <> 1)))) left join `intranet`.`OP_LOCAL` `L`
      on ((`C`.`ORGAORECEBEDOR` = `L`.`CODLOCAL`)));

