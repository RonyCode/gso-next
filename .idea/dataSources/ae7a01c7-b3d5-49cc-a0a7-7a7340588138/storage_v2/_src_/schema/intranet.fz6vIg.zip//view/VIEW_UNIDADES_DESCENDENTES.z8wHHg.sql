create definer = info@`%` view VIEW_UNIDADES_DESCENDENTES as
with recursive `AUX` (`CODUNIDADE`, `UNIDADE`, `CODUNIDADEPAI`, `I`, `SEQ`, `ARVORE_GENEALOGICA`)
                   as (select `intranet`.`VIEW_UNIDADES`.`CODUNIDADE`                                        AS `CODUNIDADE`,
                              `intranet`.`VIEW_UNIDADES`.`UNIDADE`                                           AS `UNIDADE`,
                              coalesce(`intranet`.`VIEW_UNIDADES`.`CODUNIDADEPAI`, 0)                        AS `CODUNIDADEPAI`,
                              cast('' as char(10000) charset utf8mb4)                                        AS `I`,
                              cast(`intranet`.`VIEW_UNIDADES`.`CODUNIDADE` as char(10000) charset utf8mb4)   AS `SEQ`,
                              cast(`intranet`.`VIEW_UNIDADES`.`SIGLAUNIDADE` as char(10000) charset utf8mb4) AS `ARVORE_GENEALOGICA`
                       from `intranet`.`VIEW_UNIDADES`
                       where (`intranet`.`VIEW_UNIDADES`.`CODUNIDADEPAI` = 1)
                       union all
                       select `intranet`.`C`.`CODUNIDADE`                                  AS `CODUNIDADE`,
                              `intranet`.`C`.`UNIDADE`                                     AS `UNIDADE`,
                              `intranet`.`C`.`CODUNIDADEPAI`                               AS `CODUNIDADEPAI`,
                              concat(`X`.`I`, '  ')                                        AS `CONCAT(X.I, '  ')`,
                              concat(`X`.`SEQ`, ', ', `intranet`.`C`.`CODUNIDADE`)         AS `SEQ`,
                              concat(`X`.`ARVORE_GENEALOGICA`, ' >> ',
                                     convert(`intranet`.`C`.`SIGLAUNIDADE` using utf8mb4)) AS `ARVORE_GENEALOGICA`
                       from (`intranet`.`VIEW_UNIDADES` `C` join `AUX` `X`
                             on ((`intranet`.`C`.`CODUNIDADEPAI` = `X`.`CODUNIDADE`))))
select `X`.`CODUNIDADE`                                                                      AS `CODUNIDADE`,
       `X`.`UNIDADE`                                                                         AS `UNIDADE`,
       `X`.`CODUNIDADEPAI`                                                                   AS `PAI`,
       concat(`X`.`I`, '>> ', `X`.`CODUNIDADE`, ' | ', convert(`X`.`UNIDADE` using utf8mb4)) AS `RAIZ`,
       `X`.`SEQ`                                                                             AS `SEQUENCIA`,
       `X`.`ARVORE_GENEALOGICA`                                                              AS `ASCENDENCIA`
from `AUX` `X`
order by `X`.`SEQ`;

