create definer = info@`%` view VIEW_OCORRENCIAS_FILTROS as
select `O`.`CODOCORRENCIA`                                                   AS `CODOCORRENCIA`,
       `O`.`DATA`                                                            AS `DATA_HORA`,
       date_format(`O`.`DATA`, '%d/%m/%Y')                                   AS `DATA_COMPLETA`,
       date_format(`O`.`DATA`, '%h:%i:%s')                                   AS `HORA_COMPLETA`,
       (case month(`O`.`DATA`)
            when 1 then 'Janeiro'
            when 2 then 'Fevereiro'
            when 3 then 'Março'
            when 4 then 'Abril'
            when 5 then 'Maio'
            when 6 then 'Junho'
            when 7 then 'Julho'
            when 8 then 'Agosto'
            when 9 then 'Setembro'
            when 10 then 'Outubro'
            when 11 then 'Novembro'
            else 'Dezembro' end)                                             AS `NOME_MES`,
       (case weekday(`O`.`DATA`)
            when 0 then 'Segunda-feira'
            when 1 then 'Terça-feira'
            when 2 then 'Quarta-feira'
            when 3 then 'Quinta-feira'
            when 4 then 'Sexta-feira'
            when 5 then 'Sábado'
            else 'Domingo' end)                                              AS `NOME_DIA_SEMANA`,
       dayofweek(`O`.`DATA`)                                                 AS `NUM_DIA_SEMANA`,
       date_format(`O`.`DATA`, '%d')                                         AS `NUM_DIA_MES`,
       cast(date_format(`O`.`DATA`, '%m') as unsigned)                       AS `NUM_MES`,
       date_format(`O`.`DATA`, '%Y')                                         AS `ANO`,
       cast(hour(`O`.`DATA`) as unsigned)                                    AS `NUM_HORA`,
       (case cast(hour(`O`.`DATA`) as unsigned)
            when 0 then '00:00'
            when 1 then '01:00'
            when 2 then '02:00'
            when 3 then '03:00'
            when 4 then '04:00'
            when 5 then '05:00'
            when 6 then '06:00'
            when 7 then '07:00'
            when 8 then '08:00'
            when 9 then '09:00'
            when 10 then '10:00'
            when 11 then '11:00'
            when 12 then '12:00'
            when 13 then '13:00'
            when 14 then '14:00'
            when 15 then '15:00'
            when 16 then '16:00'
            when 17 then '17:00'
            when 18 then '18:00'
            when 19 then '19:00'
            when 20 then '20:00'
            when 21 then '21:00'
            when 22 then '22:00'
            else '23:00' end)                                                AS `HORA_NORMAL`,
       minute(`O`.`DATA`)                                                    AS `MINUTO`,
       date_format(`O`.`DATA`, '%s')                                         AS `SEGUNDO`,
       (case cast(`DV`.`OBITO` as unsigned) when 0 then 0 when 1 then 1 end) AS `OBITO`
from ((`intranet`.`OP_OCORRENCIA` `O` join `intranet`.`OP_PESSOA_OCORRENCIA` `OP`
       on ((`O`.`CODOCORRENCIA` = `OP`.`CODOCORRENCIA`))) join `intranet`.`OP_DADOSVITAIS` `DV`
      on ((`DV`.`CODPESSOAOCORRENCIA` = `OP`.`CODPESSOAOCORRENCIA`)))
where (`O`.`EXCLUIDA` = false)
order by cast(date_format(`O`.`DATA`, '%m') as unsigned), dayofweek(`O`.`DATA`);

