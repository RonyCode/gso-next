create definer = info@`%` view VIEW_NATUREZAS as
select concat(substr(`A`.`NOME`, 1, 3), ' | ', substr(`N`.`NOME`, 1, 24), ' | ', `SN`.`NOME`) AS `NATUREZACOMPLETA`,
       `A`.`CODIGO`                                                                           AS `CODIGOAREA`,
       `A`.`CODAREA`                                                                          AS `CODAREA`,
       `N`.`CODIGO`                                                                           AS `CODIGONATUREZA`,
       `SN`.`CODIGO`                                                                          AS `CODIGOSUBNATUREZA`,
       `SN`.`CODSUBNATUREZA`                                                                  AS `CODSUBNATUREZA`,
       `A`.`NOME`                                                                             AS `AREA`,
       substr(`A`.`NOME`, 1, 3)                                                               AS `AREAABREVIADA`,
       `N`.`NOME`                                                                             AS `NATUREZA`,
       `SN`.`NOME`                                                                            AS `SUBNATUREZA`
from ((`intranet`.`OP_SUBNATUREZA` `SN` join `intranet`.`OP_NATUREZA` `N`) join `intranet`.`OP_AREA` `A`)
where ((`SN`.`CODNATUREZA` = `N`.`CODNATUREZA`) and (`N`.`CODAREA` = `A`.`CODAREA`) and (`A`.`ATIVO` = 1) and
       (`SN`.`ATIVO` = 1) and (`N`.`ATIVO` = 1));

