create definer = info@`%` view VW_APP_DEFESA as
select `A`.`CODAPP`      AS `CODAPP`,
       `A`.`IMEI`        AS `IMEI`,
       `A`.`TOKEN`       AS `TOKEN`,
       `A`.`DATA_ACESSO` AS `DATA_ACESSO`,
       `A`.`SITUACAO`    AS `SITUACAO`,
       `U`.`CODUSUARIO`  AS `CODUSUARIO`,
       `U`.`NOME`        AS `NOME`,
       `U`.`CPF`         AS `CPF`,
       `U`.`EMAIL`       AS `EMAIL`,
       `U`.`CELULAR`     AS `CELULAR`,
       `U`.`SENHA`       AS `SENHA`,
       `U`.`CODCIDADE`   AS `CODCIDADE`,
       `U`.`CODPERFIL`   AS `CODPERFIL`
from (`intranet`.`APP_DEFESA` `A` join `intranet`.`DC_USUARIO` `U` on ((`U`.`CODUSUARIO` = `A`.`CODUSUARIO`)));

