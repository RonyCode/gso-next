create definer = info@`%` view VIEW_FUNCIONARIOS_GERAL as
select `F`.`CODFUNC`                                    AS `CODFUNC`,
       `F`.`MATRICULA`                                  AS `MATRICULA`,
       concat(`F`.`MATRICULANOVA`, '/', `F`.`VINCULO`)  AS `MATRICULANOVA`,
       `F`.`NOME`                                       AS `NOME`,
       `intranet`.`U`.`UNIDADE`                         AS `UNIDADE`,
       `intranet`.`U`.`CIDADE`                          AS `CIDADEUNIDADE`,
       `F`.`FOTO`                                       AS `FOTO`,
       concat(`PG`.`ABREVIACAO`, ' ', `Q`.`ABREVIACAO`) AS `PGQUADRO`,
       `F`.`NOMEGUERRA`                                 AS `NOMEGUERRA`,
       `F`.`CPF`                                        AS `CPF`,
       `F`.`RG`                                         AS `RG`,
       `C`.`EMAIL1`                                     AS `EMAIL1`,
       `C`.`CELULAR`                                    AS `CELULAR`,
       `F`.`TIPO`                                       AS `TIPO`,
       `PG`.`ORDEM`                                     AS `PGORDEM`,
       `FU`.`CODUNIDADE`                                AS `CODUNIDADE`
from ((((((`intranet`.`FUNCIONARIO` `F` join `intranet`.`RH_POSTOGRADUACAO_QUADROS` `PGQ`
           on ((`F`.`CODPOSTOGRADUACAO_QUADROS` = `PGQ`.`CODPOSTOGRADUACAO_QUADROS`))) join `intranet`.`RH_QUADROS` `Q`
          on ((`PGQ`.`CODQUADROS` = `Q`.`CODQUADROS`))) join `intranet`.`RH_POSTOGRADUACAO` `PG`
         on ((`PGQ`.`CODPOSTOGRADUACAO` = `PG`.`CODPOSTOGRADUACAO`))) join `intranet`.`F_COMPLEMENTO` `C`
        on ((`F`.`CODFUNC` = `C`.`CODFUNC`))) left join `intranet`.`F_FUNCUNIDADE` `FU`
       on ((`FU`.`CODFUNC` = `F`.`CODFUNC`))) left join `intranet`.`VIEW_UNIDADES` `U`
      on ((`intranet`.`U`.`CODUNIDADE` = `FU`.`CODUNIDADE`)))
order by `F`.`NOME`;

