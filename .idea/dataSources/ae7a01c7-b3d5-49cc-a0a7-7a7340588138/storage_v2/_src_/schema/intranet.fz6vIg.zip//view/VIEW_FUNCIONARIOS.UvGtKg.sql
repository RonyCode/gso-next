create definer = info@`%` view VIEW_FUNCIONARIOS as
select `F`.`CODFUNC`                                    AS `CODFUNC`,
       `F`.`MATRICULA`                                  AS `MATRICULA`,
       concat(`F`.`MATRICULANOVA`, '/', `F`.`VINCULO`)  AS `MATRICULANOVA`,
       `F`.`NOME`                                       AS `NOME`,
       `intranet`.`U`.`UNIDADE`                         AS `UNIDADE`,
       `intranet`.`U`.`CIDADE`                          AS `CIDADEUNIDADE`,
       `F`.`FOTO`                                       AS `FOTO`,
       concat(`PG`.`ABREVIACAO`, ' ', `Q`.`ABREVIACAO`) AS `PGQUADRO`,
       `F`.`NOMEGUERRA`                                 AS `NOMEGUERRA`,
       `F`.`CPF`                                        AS `CPF`,
       `F`.`RG`                                         AS `RG`,
       `C`.`EMAIL1`                                     AS `EMAIL1`,
       `C`.`CELULAR`                                    AS `CELULAR`,
       `F`.`TIPO`                                       AS `TIPO`,
       `PG`.`ORDEM`                                     AS `PGORDEM`,
       `FU`.`CODUNIDADE`                                AS `CODUNIDADE`
from ((((((`intranet`.`FUNCIONARIO` `F` join `intranet`.`RH_POSTOGRADUACAO_QUADROS` `PGQ`) join `intranet`.`RH_QUADROS` `Q`) join `intranet`.`RH_POSTOGRADUACAO` `PG`) join `intranet`.`F_COMPLEMENTO` `C`) join `intranet`.`F_FUNCUNIDADE` `FU`) left join `intranet`.`VIEW_UNIDADES` `U`
      on ((`intranet`.`U`.`CODUNIDADE` = `FU`.`CODUNIDADE`)))
where ((`F`.`CODPOSTOGRADUACAO_QUADROS` = `PGQ`.`CODPOSTOGRADUACAO_QUADROS`) and
       (`PGQ`.`CODPOSTOGRADUACAO` = `PG`.`CODPOSTOGRADUACAO`) and (`PGQ`.`CODQUADROS` = `Q`.`CODQUADROS`) and
       (`F`.`CODFUNC` = `C`.`CODFUNC`) and (`FU`.`CODFUNC` = `F`.`CODFUNC`))
order by `F`.`NOME`;

