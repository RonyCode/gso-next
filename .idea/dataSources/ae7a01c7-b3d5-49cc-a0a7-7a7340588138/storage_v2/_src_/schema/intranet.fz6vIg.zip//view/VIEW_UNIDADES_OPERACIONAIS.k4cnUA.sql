create definer = info@`%` view VIEW_UNIDADES_OPERACIONAIS as
select `U`.`CODUNIDADE`                                                           AS `CODUNIDADE`,
       `UP`.`CODUNIDADE`                                                          AS `CODUNIDADEPAI`,
       if(`UP`.`CODUNIDADE`, concat(`U`.`SIGLA`, '/', `UP`.`SIGLA`), `U`.`SIGLA`) AS `UNIDADE`,
       `U`.`SIGLA`                                                                AS `SIGLAUNIDADE`,
       if(`UP`.`CODUNIDADE`, `UP`.`SIGLA`, '')                                    AS `SIGLAUNIDADEPAI`,
       `C`.`NOME`                                                                 AS `CIDADE`,
       `CMT`.`NOME`                                                               AS `COMANDANTE`,
       `SUB`.`NOME`                                                               AS `SUBCOMANDANTE`,
       `CMT`.`CODFUNC`                                                            AS `CODFUNCCMT`,
       `SUB`.`CODFUNC`                                                            AS `CODFUNCSUBCMT`,
       `E`.`CEP`                                                                  AS `CEP`,
       `E`.`LATITUDE`                                                             AS `LATITUDE`,
       `E`.`LONGITUDE`                                                            AS `LONGITUDE`,
       `U`.`ATUACAO`                                                              AS `ATUACAO`
from (((((`intranet`.`RH_UNIDADE` `U` left join `intranet`.`RH_UNIDADE` `UP`
          on (((`U`.`CODUNIDADEPAI` = `UP`.`CODUNIDADE`) and (`U`.`STATUS` <> 0)))) join `intranet`.`ENDERECO` `E`
         on ((`E`.`CODENDERECO` = `U`.`CODENDERECO`))) join `intranet`.`CIDADE` `C`
        on ((`C`.`CODCIDADE` = `E`.`CODCIDADE`))) left join `intranet`.`FUNCIONARIO` `CMT`
       on ((`CMT`.`CODFUNC` = `U`.`CMTUNIDADE`))) left join `intranet`.`FUNCIONARIO` `SUB`
      on ((`SUB`.`CODFUNC` = `U`.`SUBCMTUNIDADE`)))
where (`U`.`ATUACAO` = 'Operacional')
order by `UP`.`SIGLA` desc, `U`.`SIGLA`;

-- comment on column VIEW_UNIDADES_OPERACIONAIS.ATUACAO not supported: DEFINIÇÃO SE EH OPERACIONAL OU ADMINISTRATIVO

