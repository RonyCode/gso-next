create definer = info@`%` view VIEW_VEICULOSENVOLVIDOS as
select `VE`.`CONDUTOR`            AS `CONDUTOR`,
       `VE`.`CODVEICULOENVOLVIDO` AS `CODVEICULOENVOLVIDO`,
       `VE`.`CODOCORRENCIA`       AS `CODOCORRENCIA`,
       `V`.`CODVEICULO`           AS `CODVEICULO`,
       `VC`.`CATEGORIA`           AS `CATEGORIA`,
       `VC`.`CODVEICULOCATEGORIA` AS `CODVEICULOCATEGORIA`,
       `V`.`ANOFAB`               AS `ANOFAB`,
       `V`.`ANOMOD`               AS `ANOMOD`,
       `VMA`.`MARCA`              AS `MARCA`,
       `VMA`.`CODVEICULOMARCA`    AS `CODVEICULOMARCA`,
       `VMO`.`CODVEICULOMODELO`   AS `CODVEICULOMODELO`,
       `VMO`.`MODELO`             AS `MODELO`,
       `V`.`COR`                  AS `COR`,
       `V`.`CIDADE`               AS `CIDADE`,
       `V`.`PLACA`                AS `PLACA`
from ((((`intranet`.`OP_VEICULOCATEGORIA` `VC` join `intranet`.`OP_VEICULOENVOLVIDO` `VE`) join `intranet`.`OP_VEICULO` `V`) join `intranet`.`OP_VEICULOMARCA` `VMA`) join `intranet`.`OP_VEICULOMODELO` `VMO`)
where ((`V`.`CODVEICULOCATEGORIA` = `VC`.`CODVEICULOCATEGORIA`) and
       (`V`.`CODVEICULOMODELO` = `VMO`.`CODVEICULOMODELO`) and (`VMA`.`CODVEICULOMARCA` = `VMO`.`CODVEICULOMARCA`) and
       (`VE`.`CODVEICULO` = `V`.`CODVEICULO`) and (`VE`.`EXCLUIDO` <> 1));

