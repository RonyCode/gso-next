create definer = info@`%` view VIEW_UNIDADES as
select `u`.`CODUNIDADE`                                                                                     AS `CODUNIDADE`,
       `up`.`CODUNIDADE`                                                                                    AS `CODUNIDADEPAI`,
       if(`up`.`CODUNIDADE`, concat(`u`.`SIGLA`, '/', `up`.`SIGLA`),
          `u`.`SIGLA`)                                                                                      AS `UNIDADE`,
       `u`.`SIGLA`                                                                                          AS `SIGLAUNIDADE`,
       if(`up`.`CODUNIDADE`, `up`.`SIGLA`, '')                                                              AS `SIGLAUNIDADEPAI`,
       `c`.`NOME`                                                                                           AS `CIDADE`,
       `cmt`.`NOME`                                                                                         AS `COMANDANTE`,
       `sub`.`NOME`                                                                                         AS `SUBCOMANDANTE`,
       `adjunto`.`NOME`                                                                                     AS `ADJUNTO`,
       `cmt`.`CODFUNC`                                                                                      AS `CODFUNCCMT`,
       `sub`.`CODFUNC`                                                                                      AS `CODFUNCSUBCMT`,
       `adjunto`.`CODFUNC`                                                                                  AS `CODFUNCADJUNTO`,
       `e`.`CEP`                                                                                            AS `CEP`,
       `e`.`LATITUDE`                                                                                       AS `LATITUDE`,
       `e`.`LONGITUDE`                                                                                      AS `LONGITUDE`,
       concat(`e`.`LOGRADOURO`, ', ', `e`.`NUMERO`, ', ', `e`.`BAIRRO`, ', ',
              if(`e`.`COMPLEMENTO`, `e`.`COMPLEMENTO`, ''), ', ', convert(`c`.`NOME` using utf8mb3),
              '-TO')                                                                                        AS `ENDERECO`,
       `u`.`STATUS`                                                                                         AS `STATUS`,
       `u`.`ATUACAO`                                                                                        AS `ATUACAO`,
       `u`.`DESCRICAO`                                                                                      AS `DESCRICAO`
from ((((((`intranet`.`RH_UNIDADE` `u` join `intranet`.`RH_UNIDADE` `up`
           on ((`u`.`CODUNIDADEPAI` = `up`.`CODUNIDADE`))) join `intranet`.`ENDERECO` `e`
          on ((`e`.`CODENDERECO` = `u`.`CODENDERECO`))) join `intranet`.`CIDADE` `c`
         on ((`c`.`CODCIDADE` = `e`.`CODCIDADE`))) left join `intranet`.`FUNCIONARIO` `cmt`
        on ((`cmt`.`CODFUNC` = `u`.`CMTUNIDADE`))) left join `intranet`.`FUNCIONARIO` `sub`
       on ((`sub`.`CODFUNC` = `u`.`SUBCMTUNIDADE`))) left join `intranet`.`FUNCIONARIO` `adjunto`
      on ((`adjunto`.`CODFUNC` = `u`.`SUBSTITUTOCMTUNIDADE`)))
where (`u`.`STATUS` <> 0)
order by `up`.`SIGLA` desc, `u`.`SIGLA`;

-- comment on column VIEW_UNIDADES.STATUS not supported: DEFINE SE ESTÁ ATIVO OU INATIVO.

-- comment on column VIEW_UNIDADES.ATUACAO not supported: DEFINIÇÃO SE EH OPERACIONAL OU ADMINISTRATIVO

-- comment on column VIEW_UNIDADES.DESCRICAO not supported: NOME DA UNIDADE

