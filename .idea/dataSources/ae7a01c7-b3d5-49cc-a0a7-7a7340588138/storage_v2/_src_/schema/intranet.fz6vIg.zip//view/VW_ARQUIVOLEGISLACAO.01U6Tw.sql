create definer = info@`%` view VW_ARQUIVOLEGISLACAO as
select `L`.`CODARQUIVO`  AS `CODARQUIVO`,
       `L`.`NOMEARQUIVO` AS `NOMEARQUIVO`,
       `L`.`NUMERO`      AS `NUMERO`,
       `L`.`DESCRICAO`   AS `DESCRICAO`,
       `L`.`CONTEUDO`    AS `CONTEUDO`,
       `U`.`SIGLA`       AS `UNIDADE`,
       `T`.`DESCRICAO`   AS `DESCRICAOTIPO`,
       `T`.`SIGLA`       AS `SIGLA`
from ((`intranet`.`ARQUIVOLEGISLACAO` `L` join `intranet`.`TIPOARQUIVO` `T`
       on ((`T`.`CODTIPO` = `L`.`CODTIPO`))) join `intranet`.`RH_UNIDADE` `U`
      on ((`U`.`CODUNIDADE` = `L`.`CODUNIDADE`)));

