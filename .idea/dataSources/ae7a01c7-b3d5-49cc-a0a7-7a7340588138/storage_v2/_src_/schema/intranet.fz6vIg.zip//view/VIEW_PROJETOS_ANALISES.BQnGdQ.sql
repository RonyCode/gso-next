create definer = info@`%` view VIEW_PROJETOS_ANALISES as
select `intranet`.`D_ENTRADA`.`CODENTRADA`                                                              AS `CODENTRADA`,
       date_format(`intranet`.`D_ENTRADA`.`DATAHORA`, '%Y')                                             AS `Ano`,
       date_format(`intranet`.`D_ENTRADA`.`DATAHORA`, '%d/%m/%Y')                                       AS `DATA_FORMATADA`,
       `intranet`.`D_ENTRADA`.`DATAHORA`                                                                AS `DATANORMAL`,
       `intranet`.`D_ENTRADA`.`VALOR`                                                                   AS `VALOR`,
       (case `intranet`.`D_ENTRADA`.`TIPOSOLICITACAO`
            when 1 then 1
            when 2
                then 2 end)                                                                             AS `TIPO_SOLICITACAO`,
       (case `intranet`.`D_ENTRADA`.`TIPOSOLICITACAO`
            when 1 then 'Análise'
            when 2
                then 'Vistoria' end)                                                                    AS `TIPO_SOLICITACAO_EXTENSO`,
       `intranet`.`D_EQUIPES`.`EQUIPE`                                                                  AS `EQUIPE`,
       `intranet`.`TO_CIDADE`.`NOME`                                                                    AS `CIDADE`
from (((`intranet`.`D_ENTRADA` join `intranet`.`D_PROJETO`
        on ((`intranet`.`D_ENTRADA`.`CODPROJETO` = `intranet`.`D_PROJETO`.`CODPROJETO`))) join `intranet`.`D_EQUIPES`
       on ((`intranet`.`D_PROJETO`.`CODEQUIPE` = `intranet`.`D_EQUIPES`.`CODEQUIPE`))) join `intranet`.`TO_CIDADE`
      on ((`intranet`.`D_PROJETO`.`CIDADE` = `intranet`.`TO_CIDADE`.`CODCIDADE`)))
where (`intranet`.`D_PROJETO`.`EXCLUIDO` = 'N')
union
select `intranet`.`D_BOLETO`.`CODBOLETO`                                                                             AS `CODENTRADA`,
       date_format(`intranet`.`D_BOLETO`.`PAGAMENTO`, '%Y')                                                          AS `Ano`,
       date_format(`intranet`.`D_BOLETO`.`PAGAMENTO`, '%d/%m/%Y')                                                    AS `DATA_FORMATADA`,
       `intranet`.`D_BOLETO`.`PAGAMENTO`                                                                             AS `DATANORMAL`,
       `intranet`.`D_BOLETO`.`VALOR`                                                                                 AS `VALOR`,
       (case `intranet`.`D_BOLETO`.`LOCAL`
            when 1 then 3
            when 2 then 4
            when 3
                then 5 end)                                                                                          AS `TIPO_SOLICITACAO`,
       (case `intranet`.`D_BOLETO`.`LOCAL`
            when 1 then 'Protocolo'
            when 2 then 'Análise'
            when 3
                then 'Vistoria' end)                                                                                 AS `TIPO_SOLICITACAO_EXTENSO`,
       `intranet`.`TO_CIDADE`.`NOME`                                                                                 AS `NOME`,
       `intranet`.`D_EQUIPES`.`EQUIPE`                                                                               AS `EQUIPE`
from ((((`intranet`.`D_BOLETO` join `intranet`.`D_ARQUIVODIGITAL` on ((`intranet`.`D_BOLETO`.`CODARQUIVO` =
                                                                       `intranet`.`D_ARQUIVODIGITAL`.`CODARQUIVO`))) join `intranet`.`D_PROJETO`
        on ((`intranet`.`D_ARQUIVODIGITAL`.`CODPROJETO` =
             `intranet`.`D_PROJETO`.`CODPROJETO`))) join `intranet`.`D_EQUIPES`
       on ((`intranet`.`D_PROJETO`.`CODEQUIPE` = `intranet`.`D_EQUIPES`.`CODEQUIPE`))) join `intranet`.`TO_CIDADE`
      on ((`intranet`.`D_PROJETO`.`CIDADE` = `intranet`.`TO_CIDADE`.`CODCIDADE`)))
where ((`intranet`.`D_PROJETO`.`EXCLUIDO` = 'N') and (date_format(`intranet`.`D_BOLETO`.`PAGAMENTO`, '%Y') is not null))
order by `Ano`, `CODENTRADA`, `DATANORMAL`;

