create definer = info@`%` view VIEW_VITIMAS_LESOES as
select `PO`.`CODPESSOAOCORRENCIA`       AS `CODPESSOAOCORRENCIA`,
       `LPP`.`CODLESAOPARTECORPOPESSOA` AS `CODLESAOPARTECORPOPESSOA`,
       `P`.`NOME`                       AS `NOMEPESSOA`,
       `PC`.`PARTECORPO`                AS `PARTECORPO`,
       `L`.`LESAO`                      AS `LESAO`,
       `L`.`CODLESAO`                   AS `CODLESAO`,
       `PC`.`CODPARTECORPO`             AS `CODPARTECORPO`
from ((((`intranet`.`OP_LESAO_PARTECORPO_PESSOA` `LPP` join `intranet`.`OP_PARTECORPO` `PC`) join `intranet`.`OP_LESAO` `L`) join `intranet`.`OP_PESSOA_OCORRENCIA` `PO`) join `intranet`.`OP_PESSOA` `P`)
where ((`P`.`CODPESSOA` = `PO`.`CODPESSOA`) and (`LPP`.`CODLESAO` = `L`.`CODLESAO`) and
       (`LPP`.`CODPARTECORPO` = `PC`.`CODPARTECORPO`) and (`LPP`.`CODPESSOAOCORRENCIA` = `PO`.`CODPESSOAOCORRENCIA`));

