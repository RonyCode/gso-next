create definer = info@`%` view VIEW_VITIMAS_OCORRENCIAS as
select `PO`.`CODPESSOAOCORRENCIA`                AS `CODPESSOAOCORRENCIA`,
       `PO`.`CODOCORRENCIA`                      AS `CODOCORRENCIA`,
       `PO`.`CODVIATURASERVICO`                  AS `CODVIATURASERVICO`,
       `PO`.`EXCLUIDO`                           AS `EXCLUIDO`,
       `P`.`CODPESSOA`                           AS `CODPESSOA`,
       `P`.`NOME`                                AS `NOME`,
       `P`.`CPF`                                 AS `CPF`,
       `P`.`RG`                                  AS `RG`,
       `P`.`IDADEAPARENTE`                       AS `IDADEAPARENTE`,
       `P`.`TELEFONE`                            AS `TELEFONE`,
       `P`.`SEXO`                                AS `SEXO`,
       date_format(`P`.`NASCIMENTO`, '%d/%m/%Y') AS `NASCIMENTO`,
       `PO`.`RELACAO`                            AS `RELACAO`
from (`intranet`.`OP_PESSOA` `P` join `intranet`.`OP_PESSOA_OCORRENCIA` `PO`)
where ((`P`.`CODPESSOA` = `PO`.`CODPESSOA`) and (`PO`.`RELACAO` = 'VITIMA') and (`PO`.`EXCLUIDO` <> 1));

